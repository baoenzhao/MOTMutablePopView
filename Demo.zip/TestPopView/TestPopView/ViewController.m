//
//  ViewController.m
//  TestPopView
//
//  Created by orztech on 17/6/23.
//  Copyright © 2017年 orztech. All rights reserved.
//

#import "ViewController.h"
#import "MOTMutablePopView.h"

@interface ViewController () {
    int _i;
}
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (strong, nonatomic) MOTPopConfig *config;
@property (weak, nonatomic) IBOutlet UILabel *showLabel;
@property (weak, nonatomic) IBOutlet UILabel *showWidth;
@property (weak, nonatomic) IBOutlet UILabel *showHeight;
@property (weak, nonatomic) IBOutlet UISlider *widthSlider;
@property (weak, nonatomic) IBOutlet UISlider *hegihtSlider;
@property (weak, nonatomic) IBOutlet UIView *showColorView;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    [self.button addGestureRecognizer:pan];
    
    self.config = [MOTPopConfig new];
    self.config.size = CGSizeMake(60, 100);
    self.config.targetView = self.button;
    self.config.isAuto = NO;
    self.config.tabColor = [UIColor blackColor];
    
    self.showWidth.text = [NSString stringWithFormat:@"%.f", self.config.arrowWidth];
    self.showHeight.text = [NSString stringWithFormat:@"%.f", self.config.arrowheight];
    self.widthSlider.value = self.config.arrowWidth / 30.0;
    self.hegihtSlider.value = self.config.arrowheight / 30.0;
}

-(void)pan:(UIPanGestureRecognizer*) gr {
    CGPoint point = [gr locationInView:self.view];
    
    self.button.center = CGPointMake(point.x, point.y);
}

- (IBAction)click:(id)sender {
    __weak typeof(self) mySelf = self;
    [MOTMutablePopView popWithConfig:self.config ClickIndexBlock:^(NSUInteger index) {
        mySelf.showLabel.text = [NSString stringWithFormat:@"选择了第%d个", index];
    }];
}
- (IBAction)addPicTab:(id)sender {
    UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pic_Tab"]];
    _i++;
    [self.config addView:imageView];
}

- (IBAction)addTab:(id)sender {
    UILabel *label1 = [UILabel new];
    label1.textColor = [UIColor whiteColor];
    label1.text = [NSString stringWithFormat:@"%d", _i];
    label1.textAlignment = NSTextAlignmentCenter;
    _i++;
    
    [self.config addView:label1];
}
- (IBAction)addButtonTab:(id)sender {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:[NSString stringWithFormat:@"%d", _i] forState:UIControlStateNormal];
    [self.config addView:button]; 
}
- (IBAction)deleteTab:(id)sender {
    [self.config removeTabWithIndex:_i];
    _i--;
}
- (IBAction)deleteAllTabs:(id)sender {
    [self.config removeAllTab];
    _i = 0;
}
- (IBAction)hClick:(id)sender {
    self.config.popDirection = MOTPopHorizontal;
}
- (IBAction)vClick:(id)sender {
    self.config.popDirection = MOTPopVertical;
}
- (IBAction)arrowUp:(id)sender {
    self.config.arrowDirection = MOTArrowUp;
}
- (IBAction)arrowDown:(id)sender {
    self.config.arrowDirection = MOTArrowDown;
}
- (IBAction)arrowLeft:(id)sender {
    self.config.arrowDirection = MOTArrowLeft;
}
- (IBAction)arrowRight:(id)sender {
    self.config.arrowDirection = MOTArrowRight;
}
- (IBAction)vXTo100:(id)sender {
    self.config.isAuto = NO;
    self.config.vX = 100;
}
- (IBAction)autoArrow:(id)sender {
    self.config.isAuto = YES;
    self.config.vX = 0;
}
- (IBAction)arrowDirectionSwitch:(id)sender {
    UISwitch *s = (UISwitch*)sender;
    if (s.isOn) {
        self.config.inScreenAuto = NO;
    }
    else {
        self.config.inScreenAuto = YES;
    }
}
- (IBAction)backStart:(id)sender {
    self.config.vX = 0;
    self.config.inScreenAuto = YES;
    self.config.isAuto = NO;
    self.config.arrowWidth = 20;
    self.config.arrowheight = 10;
    self.showWidth.text = [NSString stringWithFormat:@"%.f", self.config.arrowWidth];
    self.showHeight.text = [NSString stringWithFormat:@"%.f", self.config.arrowheight];
    self.widthSlider.value = self.config.arrowWidth / 30.0;
    self.hegihtSlider.value = self.config.arrowheight / 30.0;
    UIColor *color = [UIColor blackColor];
    self.showColorView.backgroundColor = color;
    self.config.tabColor = color;
    [self.config removeAllTab];
    _i = 0;
    self.button.frame = CGRectMake(16, 55, self.button.frame.size.width, self.button.frame.size.height);
}
- (IBAction)changeWidth:(UISlider *)sender {
    CGFloat width = sender.value * 30.0;
    self.showWidth.text = [NSString stringWithFormat:@"%.f", width];
    self.config.arrowWidth = width;
}
- (IBAction)changeHeight:(UISlider *) sender {
    CGFloat height = sender.value * 30.0;
    self.showHeight.text = [NSString stringWithFormat:@"%.f", height];
    self.config.arrowheight = height;
}

- (IBAction)changeRandomColor:(id)sender {
    
    UIColor *color = [UIColor colorWithHue:arc4random() % 255 / 255.0 saturation:arc4random() % 255 / 255.0 brightness:arc4random() % 255 / 255.0 alpha:1.0];
    self.showColorView.backgroundColor = color;
    self.config.tabColor = color;
}

@end
